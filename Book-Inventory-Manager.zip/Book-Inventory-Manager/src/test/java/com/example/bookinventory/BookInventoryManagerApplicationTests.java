package com.example.bookinventory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookInventoryManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
