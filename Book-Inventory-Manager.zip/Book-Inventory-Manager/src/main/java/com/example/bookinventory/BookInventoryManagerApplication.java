package com.example.bookinventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookInventoryManagerApplication {
    public static void main(String[] args) {
        SpringApplication.run(BookInventoryManagerApplication.class, args);
    }
}

