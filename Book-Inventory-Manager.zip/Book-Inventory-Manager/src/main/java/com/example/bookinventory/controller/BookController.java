package com.example.bookinventory.controller;

import com.example.bookinventory.model.Book;
import com.example.bookinventory.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookService service;

    // GET /books
    @GetMapping
    public List<Book> getAllBooks() {
        return service.getAllBooks();
    }

    // GET /books/{id}
    @GetMapping("/{id}")
    public Optional<Book> getBook(@PathVariable Long id) {
        return service.getBookById(id);
    }

    // GET /books/author/{name}
    @GetMapping("/author/{name}")
    public List<Book> getByAuthor(@PathVariable String name) {
        return service.getBooksByAuthor(name);
    }

    // GET /books/available
    @GetMapping("/available")
    public List<Book> getAvailableBooks() {
        return service.getAvailableBooks();
    }

    // POST /books
    @PostMapping
    public Book addBook(@RequestBody Book book) {
        return service.saveBook(book);
    }

    // PUT /books/{id}
    @PutMapping("/{id}")
    public Book updateBook(@PathVariable Long id, @RequestBody Book book) {
        return service.updateBook(id, book);
    }

    // DELETE /books/{id}
    @DeleteMapping("/{id}")
    public void deleteBook(@PathVariable Long id) {
        service.deleteBook(id);
    }
}
