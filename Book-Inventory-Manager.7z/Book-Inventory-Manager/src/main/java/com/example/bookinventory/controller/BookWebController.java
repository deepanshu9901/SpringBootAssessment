package com.example.bookinventory.controller;

import com.example.bookinventory.model.Book;
import com.example.bookinventory.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/view/books")
public class BookWebController {

    @Autowired
    private BookService service;

    // Show list of books
    @GetMapping
    public String listBooks(Model model) {
        model.addAttribute("books", service.getAllBooks());
        return "book_list";
    }

    // Show form to add a new book
    @GetMapping("/new")
    public String showCreateForm(Model model) {
        model.addAttribute("book", new Book());
        return "create_book";
    }

    // Handle form submission to add book
    @PostMapping
    public String saveBook(@ModelAttribute Book book) {
        service.saveBook(book);
        return "redirect:/view/books";
    }

    // ✅ Delete book by id
    @GetMapping("/delete/{id}")
    public String deleteBook(@PathVariable Long id) {
        service.deleteBook(id);
        return "redirect:/view/books";
    }

    // ✅ Show form to edit book
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Book book = service.getBookById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid book Id: " + id));
        model.addAttribute("book", book);
        return "edit_book";
    }

    // ✅ Handle form submission for update
    @PostMapping("/update/{id}")
    public String updateBook(@PathVariable Long id, @ModelAttribute Book book) {
        service.updateBook(id, book);
        return "redirect:/view/books";
    }
}
